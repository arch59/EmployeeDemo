package com.cg.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.bean.Employee;
import com.cg.employee.dao.IEmployeeDao;

@Service
public class EmployeeService implements IEmployeeService {

	@Autowired
	IEmployeeDao empdao;

	/*
	 * method name:addEmployee 
	 * creation date:4-10-2019 
	 * Author:Capgemini description:
	 * Adding employee in database
	 */
	public Employee addEmployee(Employee employee) {
		return empdao.addEmployee(employee);
	}
	/*
	 * method name:getAllEmployeeDetails 
	 * creation date:4-10-2019 
	 * Author:Capgemini
	 * description: Retreiving all employees from database
	 */

	@Override
	public List<Employee> getAllEmployeeDetails() {
		return empdao.getAllEmployeeDetails();
	}
	/*
	 * method name:deleteEmployee 
	 * creation date:4-10-2019 
	 * Author:Capgemini
	 * description: Deleting employee from database
	 */

	@Override
	public Employee deleteEmployee(String empId) {
		return empdao.deleteEmployee(empId);
	}
	
	 /* method name:getById 
	  creation date:4-10-2019
	  Author:Capgemini
	  description: Retreiving employee using Id*/
	  
	  
	  @Override public Employee getById(String empId) { return
	  empdao.getById(empId); }
	  
	  /*method name:updateEmployee
	   *  creation date:4-10-2019
	   *  Author:Capgemini
	   *  description: updating employee in database
	   */
	 

	@Override
	public Employee updateEmployee(String empId, Employee employee) {
		return empdao.updateEmployee(empId, employee);
	}
	/*
	 * method name: modify 
	 * creation date:4-10-2019
	 * Author:Capgemini
	 * description: Modifying employee in database
	 */

	@Override
	public Employee modify(Employee employee) {
		return empdao.modify(employee);
	}

}
