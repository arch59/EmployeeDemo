package com.cg.employee.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.employee.bean.Employee;

@Repository
public class EmployeeDao implements IEmployeeDao {
@Autowired
MongoTemplate mongotemplate;

	@Override
	public Employee addEmployee(Employee employee) {
		return mongotemplate.save(employee);
	}

	@Override
	public List<Employee> getAllEmployeeDetails() {
		return mongotemplate.findAll(Employee.class);
	}

	@Override
	public Employee deleteEmployee(String empId) {
		Employee employee=getById1(empId);
				if(employee!=null) {
		          mongotemplate.remove(employee);			
				}
				return employee;
			}
			private Employee getById1(String empId) {
				Query query = new Query();
				query.addCriteria(Criteria.where("empId").is(empId));
			return	mongotemplate.findOne(query, Employee.class);
	}

			@Override
			public Employee getById(String empId) {
				Query query = new Query();
				query.addCriteria(Criteria.where("empId").is(empId));
			return	mongotemplate.findOne(query, Employee.class);
	
			}

			@Override
			public Employee updateEmployee(String empId,Employee employee) {
				Query query = new Query();
				query.addCriteria(Criteria.where("empId").is(employee.getEmpId()));
				return mongotemplate.findOne(query,Employee.class);
				
			}

			@Override
			public Employee modify(Employee employee) {
				Query query = new Query();
				query.addCriteria(Criteria.where("empId").is(employee.getEmpId()));
				mongotemplate.find(query, Employee.class);
				mongotemplate.save(employee);
				return employee;
			}
}
