package com.cg.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.IEmployeeService;

@Controller
public class EmpController {
	@Autowired
	IEmployeeService empservice;

	@RequestMapping("/index")
	public ModelAndView welcomePage() {
		return new ModelAndView("index");
	}

	@RequestMapping("/addDetails")
	public ModelAndView addEmployees() {
		return new ModelAndView("addDetails", "employee", new Employee());
	}

	@RequestMapping("/addEmployeeDetails")
	public ModelAndView addEmployeeDetails(@ModelAttribute Employee employee) {
		Employee bean = empservice.addEmployee(employee);
		ModelAndView view = new ModelAndView("addEmployeeDetails", "bean", bean);
		return view;
	}

	@RequestMapping("/viewallEmployee")
	public ModelAndView getDetails() {
		ModelAndView view = new ModelAndView();

		List<Employee> list = empservice.getAllEmployeeDetails();
		if (list.isEmpty()) {
			String Message = "There are no employees";
			view.setViewName("myerror");
			view.addObject("msg", Message);
		} else {
			view.setViewName("viewallEmployee");
			view.addObject("list", list);
		}
		return view;
	}

	@RequestMapping("/deleteEmployee")
	public ModelAndView deleteEmployees() {
		Employee employee = new Employee();
		return new ModelAndView("deleteEmployee", "employee", employee);
	}

	@RequestMapping("/deleteSuccess")
	public ModelAndView deleteEmployee(@ModelAttribute Employee employee) throws EmployeeException{
		Employee employee1 = new Employee();
		ModelAndView view=null;
		try {
			employee1=empservice.deleteEmployee(employee.getEmpId());
			if(employee1==null) {
				throw new EmployeeException("Incorrect ID");
			}
		view = new ModelAndView("deleteSuccess", "employee1", employee1);
	}catch(Exception e) {
		throw new EmployeeException("Incorrect ID");
	}
		return view;
	}

	@RequestMapping("/getdetailsByID")
	public ModelAndView getdetailsById() {
		Employee employee = new Employee();
		return new ModelAndView("getdetailsByID", "employee", employee);
	}

	@RequestMapping("/getByID")
	public ModelAndView getById(@ModelAttribute Employee employee) throws EmployeeException {
		Employee employee2 = new Employee();
		ModelAndView view=null;
				try {
			employee2=empservice.getById(employee.getEmpId());
			if(employee2==null) {
			throw new EmployeeException("Incorrect Id");
				}
		view=new ModelAndView("getByID", "employee2", employee2);
	}catch(Exception e) {
		throw new EmployeeException("Incorrect ID");
	}
return view;
}

	@RequestMapping("/updateEmployeeDetails")
	public ModelAndView updateEmployeeDetails() {
		Employee employee = new Employee();
		return new ModelAndView("updateEmployeeDetails", "employee", employee);
	}

	@RequestMapping("/updateDetails")
	private ModelAndView updateEmployee(@ModelAttribute Employee employee) {
		Employee employee2 = empservice.updateEmployee(employee.getEmpId(), employee);
		return new ModelAndView("updateDetails", "employee", employee2);
	}

	@RequestMapping("/updateSuccess")
	public ModelAndView updateSuccess(@ModelAttribute Employee employee) {
		Employee emp = empservice.modify(employee);
		ModelAndView view = new ModelAndView("updateSuccess");
		return view;

	}
}
