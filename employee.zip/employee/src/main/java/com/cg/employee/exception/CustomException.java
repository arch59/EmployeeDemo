package com.cg.employee.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class CustomException {
	@ExceptionHandler(value= {Exception.class})
	public String handleConflict(Model model,Exception ex,HttpServletRequest req) {
		return "errorPage";
	}

}
