package com.cg.employee.bean;

import javax.validation.constraints.Size;


import org.springframework.data.annotation.Id;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Employee {
	
	@Id
	private String empId;
	private String empName;
	private String salary;
	public Employee() {
		super();
	}
	public Employee(String empId, String empName, String salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	

}
